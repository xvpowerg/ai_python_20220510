import pandas as pd
sales=pd.read_csv("salesv2.csv",parse_dates=['date'])
print(sales.head())
print("----------1-----------")
#請加入語法
print("----------2-----------")
#請加入語法
print("----------3-----------")
#請加入語法
print("----------4-----------")